"use client"

import SeverityBadge from "../frontend/src/components/Common/SeverityBadge"

export default function SyntheticV0PageForDeployment() {
  return <SeverityBadge />
}