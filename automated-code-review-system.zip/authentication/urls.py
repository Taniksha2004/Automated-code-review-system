from django.urls import path
from rest_framework_simplejwt.views import TokenRefreshView
from . import views

urlpatterns = [
    # Authentication
    path('register/', views.RegisterView.as_view(), name='register'),
    path('login/', views.LoginView.as_view(), name='login'),
    path('logout/', views.logout_view, name='logout'),
    path('token/refresh/', TokenRefreshView.as_view(), name='token_refresh'),
    
    # User Profile
    path('profile/', views.ProfileView.as_view(), name='profile'),
    
    # API Tokens
    path('tokens/', views.APITokenListCreateView.as_view(), name='api_tokens'),
    path('tokens/<uuid:pk>/', views.APITokenDetailView.as_view(), name='api_token_detail'),
]
