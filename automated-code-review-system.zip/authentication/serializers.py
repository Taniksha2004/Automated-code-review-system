from rest_framework import serializers
from django.contrib.auth import authenticate
from .models import User, APIToken
import secrets

class UserRegistrationSerializer(serializers.ModelSerializer):
    password = serializers.CharField(write_only=True, min_length=8)
    password_confirm = serializers.CharField(write_only=True)
    
    class Meta:
        model = User
        fields = ('email', 'first_name', 'last_name', 'password', 'password_confirm')
    
    def validate(self, attrs):
        if attrs['password'] != attrs['password_confirm']:
            raise serializers.ValidationError("Passwords don't match")
        return attrs
    
    def create(self, validated_data):
        validated_data.pop('password_confirm')
        user = User.objects.create_user(**validated_data)
        return user

class UserLoginSerializer(serializers.Serializer):
    email = serializers.EmailField()
    password = serializers.CharField()
    
    def validate(self, attrs):
        email = attrs.get('email')
        password = attrs.get('password')
        
        if email and password:
            user = authenticate(email=email, password=password)
            if not user:
                raise serializers.ValidationError('Invalid credentials')
            if not user.is_active:
                raise serializers.ValidationError('User account is disabled')
            attrs['user'] = user
        else:
            raise serializers.ValidationError('Must include email and password')
        
        return attrs

class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ('id', 'email', 'first_name', 'last_name', 'created_at')
        read_only_fields = ('id', 'created_at')

class APITokenSerializer(serializers.ModelSerializer):
    token = serializers.CharField(read_only=True)
    
    class Meta:
        model = APIToken
        fields = ('id', 'name', 'token', 'is_active', 'created_at', 'last_used')
        read_only_fields = ('id', 'token', 'created_at', 'last_used')
    
    def create(self, validated_data):
        validated_data['user'] = self.context['request'].user
        validated_data['token'] = secrets.token_urlsafe(32)
        return super().create(validated_data)
