from rest_framework import generics, permissions
from rest_framework.decorators import api_view, permission_classes
from rest_framework.response import Response
from django.db.models import Count, Avg, Sum, Q
from django.utils import timezone
from datetime import timedelta
from reviews.models import CodeSubmission, ReviewResult, Issue
from reviews.serializers import CodeSubmissionSerializer
from .serializers import DashboardOverviewSerializer, AnalyticsSerializer, ProjectStatsSerializer
from .models import ProjectStats

@api_view(['GET'])
@permission_classes([permissions.IsAuthenticated])
def dashboard_overview_view(request):
    """Get dashboard overview statistics"""
    user = request.user
    
    # Get submission statistics
    submissions = CodeSubmission.objects.filter(user=user)
    
    stats = {
        'total_submissions': submissions.count(),
        'completed_submissions': submissions.filter(status='completed').count(),
        'pending_submissions': submissions.filter(status__in=['pending', 'processing']).count(),
        'failed_submissions': submissions.filter(status='failed').count(),
    }
    
    # Calculate average score
    completed_submissions = submissions.filter(status='completed')
    avg_score = completed_submissions.aggregate(
        avg_score=Avg('result__overall_score')
    )['avg_score'] or 0.0
    
    stats['average_score'] = round(avg_score, 2)
    
    # Total issues
    total_issues = Issue.objects.filter(
        result__submission__user=user
    ).count()
    stats['total_issues'] = total_issues
    
    # Recent submissions
    recent_submissions = submissions.order_by('-submitted_at')[:5]
    stats['recent_submissions'] = CodeSubmissionSerializer(
        recent_submissions, many=True
    ).data
    
    serializer = DashboardOverviewSerializer(stats)
    return Response(serializer.data)

@api_view(['GET'])
@permission_classes([permissions.IsAuthenticated])
def analytics_view(request):
    """Get analytics data for charts"""
    user = request.user
    days = int(request.query_params.get('range', 30))
    
    # Date range
    end_date = timezone.now()
    start_date = end_date - timedelta(days=days)
    
    # Submissions over time
    submissions_over_time = []
    for i in range(days):
        date = start_date + timedelta(days=i)
        count = CodeSubmission.objects.filter(
            user=user,
            submitted_at__date=date.date()
        ).count()
        submissions_over_time.append({
            'date': date.strftime('%Y-%m-%d'),
            'count': count
        })
    
    # Issues by severity
    issues_by_severity = Issue.objects.filter(
        result__submission__user=user,
        result__submission__submitted_at__gte=start_date
    ).values('severity').annotate(count=Count('id'))
    
    severity_dict = {item['severity']: item['count'] for item in issues_by_severity}
    
    # Languages usage
    languages_usage = CodeSubmission.objects.filter(
        user=user,
        submitted_at__gte=start_date
    ).values('language__name').annotate(
        count=Count('id')
    ).order_by('-count')
    
    # Score distribution
    score_ranges = [
        (90, 100, 'Excellent'),
        (80, 89, 'Good'),
        (70, 79, 'Fair'),
        (60, 69, 'Poor'),
        (0, 59, 'Very Poor')
    ]
    
    score_distribution = []
    for min_score, max_score, label in score_ranges:
        count = ReviewResult.objects.filter(
            submission__user=user,
            submission__submitted_at__gte=start_date,
            overall_score__gte=min_score,
            overall_score__lte=max_score
        ).count()
        score_distribution.append({
            'range': label,
            'count': count
        })
    
    analytics_data = {
        'submissions_over_time': submissions_over_time,
        'issues_by_severity': severity_dict,
        'languages_usage': list(languages_usage),
        'score_distribution': score_distribution
    }
    
    serializer = AnalyticsSerializer(analytics_data)
    return Response(serializer.data)

class ProjectStatsListView(generics.ListAPIView):
    """List project statistics for user"""
    serializer_class = ProjectStatsSerializer
    permission_classes = [permissions.IsAuthenticated]
    
    def get_queryset(self):
        return ProjectStats.objects.filter(user=self.request.user).order_by('-updated_at')

@api_view(['GET'])
@permission_classes([permissions.IsAuthenticated])
def code_quality_trends_view(request):
    """Get code quality trends over time"""
    user = request.user
    days = int(request.query_params.get('range', 30))
    
    end_date = timezone.now()
    start_date = end_date - timedelta(days=days)
    
    # Weekly averages
    trends = []
    current_date = start_date
    
    while current_date < end_date:
        week_end = min(current_date + timedelta(days=7), end_date)
        
        week_submissions = CodeSubmission.objects.filter(
            user=user,
            status='completed',
            submitted_at__gte=current_date,
            submitted_at__lt=week_end
        )
        
        if week_submissions.exists():
            avg_score = week_submissions.aggregate(
                avg_score=Avg('result__overall_score')
            )['avg_score']
            
            total_issues = Issue.objects.filter(
                result__submission__in=week_submissions
            ).count()
            
            trends.append({
                'week_start': current_date.strftime('%Y-%m-%d'),
                'average_score': round(avg_score, 2),
                'total_issues': total_issues,
                'submissions_count': week_submissions.count()
            })
        
        current_date = week_end
    
    return Response({'trends': trends})
