from django.db import models
from django.contrib.auth import get_user_model

User = get_user_model()

class ProjectStats(models.Model):
    """Project-level statistics"""
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='project_stats')
    project_name = models.CharField(max_length=200)
    total_files = models.IntegerField(default=0)
    total_issues = models.IntegerField(default=0)
    average_score = models.FloatField(default=0.0)
    last_analysis = models.DateTimeField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        db_table = 'project_stats'
        unique_together = ['user', 'project_name']
    
    def __str__(self):
        return f"{self.user.email} - {self.project_name}"
