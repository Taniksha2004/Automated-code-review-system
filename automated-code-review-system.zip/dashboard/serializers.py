from rest_framework import serializers
from reviews.models import CodeSubmission, ReviewResult, Issue
from authentication.models import User
from .models import ProjectStats
from django.db.models import Count, Avg, Sum
from django.utils import timezone
from datetime import timedelta

class DashboardOverviewSerializer(serializers.Serializer):
    """Dashboard overview statistics"""
    total_submissions = serializers.IntegerField()
    completed_submissions = serializers.IntegerField()
    pending_submissions = serializers.IntegerField()
    failed_submissions = serializers.IntegerField()
    average_score = serializers.FloatField()
    total_issues = serializers.IntegerField()
    recent_submissions = serializers.ListField()

class AnalyticsSerializer(serializers.Serializer):
    """Analytics data for charts and graphs"""
    submissions_over_time = serializers.ListField()
    issues_by_severity = serializers.DictField()
    languages_usage = serializers.ListField()
    score_distribution = serializers.ListField()

class ProjectStatsSerializer(serializers.ModelSerializer):
    class Meta:
        model = ProjectStats
        fields = (
            'id', 'project_name', 'total_files', 'total_issues',
            'average_score', 'last_analysis', 'created_at'
        )
