from django.urls import path
from . import views

urlpatterns = [
    # Dashboard
    path('overview/', views.dashboard_overview_view, name='dashboard_overview'),
    path('analytics/', views.analytics_view, name='analytics'),
    path('trends/', views.code_quality_trends_view, name='code_quality_trends'),
    
    # Projects
    path('projects/', views.ProjectStatsListView.as_view(), name='project_stats'),
]
